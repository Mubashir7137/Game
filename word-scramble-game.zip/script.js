const words = ["javascript", "function", "variable", "object", "program"];
let currentWord = "";
let scrambled = "";
let score = 0;
let timer;
let timeLeft = 30;

function scrambleWord(word) {
  return word.split('').sort(() => Math.random() - 0.5).join('');
}

function startGame() {
  score = 0;
  timeLeft = 30;
  document.getElementById("score").innerText = "Score: 0";
  document.getElementById("message").innerText = "";
  nextWord();
  timer = setInterval(() => {
    timeLeft--;
    document.getElementById("timer").innerText = "Time: " + timeLeft;
    if (timeLeft === 0) {
      clearInterval(timer);
      document.getElementById("message").innerText = "Time's up!";
    }
  }, 1000);
}

function nextWord() {
  const randomIndex = Math.floor(Math.random() * words.length);
  currentWord = words[randomIndex];
  scrambled = scrambleWord(currentWord);
  document.getElementById("scrambled-word").innerText = scrambled;
  document.getElementById("user-input").value = "";
}

function checkWord() {
  const input = document.getElementById("user-input").value.toLowerCase();
  if (input === currentWord) {
    score++;
    document.getElementById("score").innerText = "Score: " + score;
    document.getElementById("message").innerText = "Correct!";
    nextWord();
  } else {
    document.getElementById("message").innerText = "Try again!";
  }
}
